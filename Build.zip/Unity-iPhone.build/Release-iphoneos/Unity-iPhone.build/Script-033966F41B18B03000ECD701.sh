#!/bin/sh
"$PROJECT_DIR/MapFileParser.sh"
